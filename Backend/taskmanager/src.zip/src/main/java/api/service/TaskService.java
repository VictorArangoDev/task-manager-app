package api.service;

import api.exception.IllegalArgumentException;
import api.exception.ResourceNotFoundException;
import api.model.Priority;
import api.model.Project;
import api.model.StateProjectTask;
import api.model.Task;
import api.repository.PriorityRepository;
import api.repository.ProjectRepository;
import api.repository.StateProjectTaskRepository;
import api.repository.TaskRepository;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final PriorityRepository priorityRepository;
    private final StateProjectTaskRepository stateRepository;
    private final ProjectRepository projectRepository;

    public TaskService(
        TaskRepository taskRepository,
        PriorityRepository priorityRepository,
        StateProjectTaskRepository stateRepository,
        ProjectRepository projectRepository
    ) {
        this.taskRepository = taskRepository;
        this.priorityRepository = priorityRepository;
        this.stateRepository = stateRepository;
        this.projectRepository = projectRepository;
    }

    // Retorna todas las tareas
    public List<Task> findAll() {
        return taskRepository.findAll();
    }

    // Busca una tarea por id — lanza excepción si no existe
    public Task findById(Long id) {
        return taskRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Tarea no encontrada"));
    }

    // Crea una nueva tarea validando que existan todas las relaciones
    public Task create(Task task) {

        // Valida y obtiene el estado completo desde la BD
        if (task.getStateProjectTask() == null || task.getStateProjectTask().getId() == null) {
            throw new IllegalArgumentException("El estado es obligatorio");
        }
        StateProjectTask state = stateRepository.findById(task.getStateProjectTask().getId())
            .orElseThrow(() -> new ResourceNotFoundException("Estado no encontrado"));

        // Valida y obtiene la prioridad completa desde la BD
        if (task.getPriority() == null || task.getPriority().getId() == null) {
            throw new IllegalArgumentException("La prioridad es obligatoria");
        }
        Priority priority = priorityRepository.findById(task.getPriority().getId())
            .orElseThrow(() -> new ResourceNotFoundException("Prioridad no encontrada"));

        // Valida y obtiene el proyecto completo desde la BD
        if (task.getProject() == null || task.getProject().getId() == null) {
            throw new IllegalArgumentException("El proyecto es obligatorio");
        }
        Project project = projectRepository.findById(task.getProject().getId())
            .orElseThrow(() -> new ResourceNotFoundException("Proyecto no encontrado"));

        // Asigna las relaciones completas
        task.setStateProjectTask(state);
        task.setPriority(priority);
        task.setProject(project);

        return taskRepository.save(task);
    }

    // Actualiza los campos editables de una tarea
    public Task update(Long id, Task taskDetails) {
        Task task = taskRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Tarea no encontrada"));

        // Solo actualiza los campos que vienen en el request
        if (taskDetails.getName() != null && !taskDetails.getName().trim().isEmpty()) {
            task.setName(taskDetails.getName());
        }
        if (taskDetails.getDescription() != null) {
            task.setDescription(taskDetails.getDescription());
        }
        if (taskDetails.getStartDate() != null) {
            task.setStartDate(taskDetails.getStartDate());
        }
        if (taskDetails.getEndDate() != null) {
            task.setEndDate(taskDetails.getEndDate());
        }
        if (taskDetails.getDeadline() != null) {
            task.setDeadline(taskDetails.getDeadline());
        }
        // Actualiza prioridad si viene en el request
        if (taskDetails.getPriority() != null && taskDetails.getPriority().getId() != null) {
            Priority priority = priorityRepository.findById(taskDetails.getPriority().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Prioridad no encontrada"));
            task.setPriority(priority);
        }

        return taskRepository.save(task);
    }

    // Cambia el estado de una tarea — TODO → IN_PROGRESS → DONE → CANCELLED
    public Task updateStatus(Long id, Long stateId) {
        Task task = taskRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Tarea no encontrada"));

        StateProjectTask state = stateRepository.findById(stateId)
            .orElseThrow(() -> new ResourceNotFoundException("Estado no encontrado"));

        task.setStateProjectTask(state);
        return taskRepository.save(task);
    }
}